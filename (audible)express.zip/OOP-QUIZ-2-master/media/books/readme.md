the images(template) for books
